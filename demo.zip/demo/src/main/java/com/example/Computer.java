package com.example;

public interface Computer {
    void compile();
}
