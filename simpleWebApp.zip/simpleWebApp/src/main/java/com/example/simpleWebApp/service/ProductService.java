package com.example.simpleWebApp.service;
import com.example.simpleWebApp.model.Product;

import java.util.*;

import org.springframework.stereotype.Service;
@Service
public class ProductService {
    List<Product> products=new ArrayList<>(Arrays.asList(
            new Product(1,"Laptop",800.00),
            new Product(2,"Smartphone",500.00),
            new Product(3,"Tablet",300.00),
            new Product(4,"Monitor",150.00)
    ));
    public List<Product> getAllProducts() {
        return products;
    }
    //1
    // public Product findById(int id){
    //     for(Product product:products){
    //         if(product.getId()==id){
    //             return product;
    //         }
    //     }
    //     return null;
    // }

    //2 using Stream API
    public Product findById(int id){
        return products.stream()
                .filter(product -> product.getProductId() == id)
                .findFirst()
                .orElse(new Product(0,"Not Found",0.00));
    }
    public void addProduct(Product product){
        products.add(product);
    }
    public Product deleteProduct(int id){
        Product product = findById(id); // Reuse findById method to get the product which user wants to delete as we need to return it
        products.remove(product);
        return product;
    }
    public Product updateProduct(int id, Product entity) {
        // Find the product by id
        Product existingProduct = findById(id);
        // Update the product details (for simplicity, just updating the name here)
        System.out.println("Updating product with id: " + id + " to new entity: " + entity);
        existingProduct.setProductId(id);
        if (entity.getProductName() != null) {
        existingProduct.setProductName(entity.getProductName());
        }
        if (entity.getProductPrice() != null) {
            existingProduct.setProductPrice(entity.getProductPrice());
        }

        return existingProduct;
    }
    public Product updateProduct(Product entity) {
        int index=-1;
        for(int i=0;i<products.size();i++){
            if(products.get(i).getProductId() == entity.getProductId()) {
                index=i;
                break;
            }
        }
        if(index==-1){
            throw new RuntimeException("Product not found with id: " + entity.getProductId()); 
        }
        products.set(index, entity);
        return entity;
    }
}
