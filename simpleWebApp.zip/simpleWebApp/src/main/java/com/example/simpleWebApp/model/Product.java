package com.example.simpleWebApp.model;

import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor // Generates constructor with all arguments
// @AllArgsConstructor generates only constructor
// @Data generates getters, setters, toString, equals, hashCode
@NoArgsConstructor   // 🔥 REQUIRED
public class Product {
    // Nothing is “wrong” syntactically if you use int and double, but your REST API will break on partial JSON updates because Jackson cannot assign null to primitive types.
    private Integer productId;
    private String productName;
    private Double productPrice;

    //Already created by Lombok
    // public int getProductId() {
    //     return productId;
    // }
    // public String getProductName() {
    //     return productName;
    // }
    // public void setProductName(String productName) {
    //     this.productName = productName;
    // }
    // public double getProductPrice() {
    //     return productPrice;
    // }
    // public void setProductPrice(double productPrice) {
    //     this.productPrice = productPrice;
    // }
}